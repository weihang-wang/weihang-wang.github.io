$(function() {
	if ($ && $.fancybox) {	
	$(".acc-prom").fancybox({
		'width'				: '75%',
		'height'			: '75%',
        'autoScale'     	: false,
        'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});
	
	}

	if ($ && $.fancybox) {	
	$(".lightbox").fancybox({
		'width'				: '75%',
		'height'			: '35%',
        'autoScale'     	: false,
        'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});
	
	}

	if ($ && $.fancybox) {	
	$(".optionOffers").fancybox({
		'width'				: '75%',
		'height'			: '75%',
        'autoScale'     	: false,
        'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});
	
	}

	if ($ && $.fancybox) {	
	$("#GSI_pop-up").fancybox({
		'width'				: '75%',
		'height'			: '75%',
        'autoScale'     	: false,
        'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});
	
	}

}); 